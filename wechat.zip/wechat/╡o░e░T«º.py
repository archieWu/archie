import json
import requests
url_msg ='https://api.weixin.qq.com/cgi-bin/message/custom/send?'
body = {
        "touser": 'xxxxx',#將關注公眾號測試賬號的使用者id填入
        "msgtype":"text",
        "text":{
         "content":"hello"#輸入要發送的訊息
        }
    }

res =requests.post(url=url_msg,params = {
         'access_token': 'xxxxxxxxxxxx'#將前面獲取到的token
    },data=json.dumps(body,ensure_ascii=False).encode('utf-8'))