import requests

url_token = 'https://api.weixin.qq.com/cgi-bin/token?'
res = requests.get(url=url_token,params={
         "grant_type": 'client_credential',
         'appid':'xxxxxxxxxx',# 填寫獲取到的appID
         'secret':'xxxxxxxxxxxxxx',# 填寫獲取到的appsecret
         }).json()
print(res)
token = res.get('access_token')
print(res)