#!/usr/bin/env python
# coding: utf-8

from newsapi import NewsApiClient
import json
from bs4 import BeautifulSoup as bs
from lxml import html
from lxml import cssselect

newsapi = NewsApiClient(api_key='f3c5db312bef465fb04c7a3cdf9304ae')

all_articles = newsapi.get_everything(q='武漢肺炎 NOT 外遇',
                                      domains='ettoday.net,storm.mg,chinatimes.com,udn.com',
                                      from_param='2020-05-05',
                                      to='2020-06-05',
                                      language='zh',
                                      sort_by='publishedAt',
                                      page_size=100)


file_name = 'Exam2.json'
for i in all_articles['articles']:
    print(i,'\n')
    with open(file_name,'a' ,encoding = 'utf8' ) as file_object:
        json.dump(i,file_object,ensure_ascii=False)
        file_object.write(',')

