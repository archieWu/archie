#!/usr/bin/env python
# coding: utf-8

import requests
import json
from bs4 import BeautifulSoup as bs
from lxml import html
from lxml import cssselect

res = requests.get('https://technews.tw/')
soup = bs(res.text,'lxml')


print(type(soup))
soup


row_titles = soup.select('#album_test1 > div > ul > li ')


print(type(row_titles))
row_titles

results=[]
for i,j in enumerate(row_titles):
    try:
        results=[]
        for i,j in enumerate(row_titles):
            result={} 
            spotlists=[]
            i+=1
            result['category'] = j.find('div','cat01').text
            result['sum_title'] = j.find('h3').text
            result['sum_title_url'] ='https:'+j.find('a').get('href')
            raw_titles = soup.select('#album_test1 > div > ul > li:nth-child({}) > div.itemelse > ul > li > a'.format(i))
            for k in raw_titles:
                spotlist={}
                spotlist['title'] =k.text
                spotlist['url'] ='https:'+k.get('href')
                spotlists.append(spotlist)
            result['spotlist']=spotlists
            results.append(result)
    except Exception as e:
        print(e)
        print(i)
        continue
results


file_name = 'Exam1_1.json'
with open(file_name,'w', encoding = 'utf8' ) as file_object:
        json.dump(results,file_object,ensure_ascii=False)


file_name = 'Exam1_1.json'
with open(file_name,'r', encoding = 'utf8' ) as file_object:
    jf = json.loads(file_object.read())
jf


for i,j in enumerate(jf):
    
    sum_all=''
    url=jf[0]['sum_title_url']
    res = requests.get(url)
    soup = bs(res.text,'lxml')
    row_titles = soup.select('div > div.entry-content > div.indent > p')
    for p in row_titles:
        sum_all=sum_all+p.text

    file_name_sum = ('sum_{}_{}.txt'.format(jf[i]['category'],jf[i]['sum_title'][0:4]))
    with open(file_name_sum,'w', encoding = 'utf8' ) as file_object:
        json.dump(sum_all,file_object,ensure_ascii=False)
        
    for k in range(3):
        url=jf[i]['spotlist'][k]['url']
        spot_all=''
        res = requests.get(url)
        soup = bs(res.text,'lxml')
        row_titles = soup.select('div > div.entry-content > div.indent > p')
        for p in row_titles:
            spot_all=spot_all+p.text

        file_name_spot = ('spot_{}_{}.txt'.format(jf[i]['category'],jf[i]['spotlist'][k]['title'][0:4]))
        with open(file_name_spot,'w', encoding = 'utf8' ) as file_object:
            json.dump(spot_all,file_object,ensure_ascii=False)

