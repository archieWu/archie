import requests

def lineNotifyMessage(token, msg):
    headers = {
        "Authorization": "Bearer " + token, 
        "Content-Type" : "application/x-www-form-urlencoded"
    }

    payload = {'message': msg}
    r = requests.post("https://notify-api.line.me/api/notify", headers = headers, params = payload)
    return r.status_code

msg = 'test test'#要發送的內容
token = 'xxxxxxxxxxxxxxx'#獲取到的token

lineNotifyMessage(token, msg)