package javahomework;

public class Client2 {

	public static void main(String[] args) {
		FibonacciMethod f =new FibonacciMethod();
		System.out.println(f.Fibonacci(2));

	}

}
