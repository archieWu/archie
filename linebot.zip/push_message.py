from linebot import LineBotApi
from linebot.models import TextSendMessage
from linebot.exceptions import LineBotApiError
user_id='xxxxxxxxxx' #要傳送訊息的使用者id
line_bot_api = LineBotApi('xxxxxxxxxxx')#Channel access token 

try:
    line_bot_api.push_message(user_id, TextSendMessage(text='123'))
except LineBotApiError as e:
    print(e)